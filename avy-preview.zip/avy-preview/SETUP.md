# Setting Up go.adventurebyyou.com

This gives you clean, branded links for WhatsApp/social sharing that show the
correct title, description, and photo — for any page you add to the list.

## One-time setup (about 10 minutes)

### 1. Put this project on GitHub
- Go to github.com, log in (or create a free account)
- Click the **+** in the top right → **New repository**
- Name it something like `avy-preview` → Create
- On the next screen, click **uploading an existing file**
- Drag in all the files from this folder (`api/preview.js`, `vercel.json`, `package.json`)
- Commit

### 2. Connect it to Vercel (free)
- Go to vercel.com → sign up/log in with your GitHub account
- Click **Add New Project**
- Select the `avy-preview` repo you just created
- Click **Deploy** (no settings to change — just click through)

### 3. Add your subdomain
- In the Vercel project, go to **Settings → Domains**
- Type `go.adventurebyyou.com` → Add
- Vercel will show you a CNAME record to add (something like `cname.vercel-dns.com`)
- Go to wherever you manage adventurebyyou.com's DNS (GoDaddy, Namecheap, Cloudflare, etc.)
- Add a CNAME record: **go** → the value Vercel gave you
- Wait a few minutes for it to activate (Vercel will show a green checkmark)

That's it — permanent setup, done once.

## Using it going forward

Share links in this format:
```
https://go.adventurebyyou.com/zadun-los-cabos
```

Real people who tap it land on the actual page. Crawlers (WhatsApp, Facebook,
etc.) see the correct preview.

## Adding a new page

Open `api/preview.js`, add an entry to the `PAGES` list at the top, e.g.:

```js
'become-affiliate': {
  path: '/become-affiliate',
  title: 'Become an Adventure By You Affiliate',
  description: 'Your own description here.',
  image: 'https://your-image-url.jpg',
},
```

Save, push the change to GitHub (or re-upload the file) — Vercel redeploys
automatically in about 30 seconds. Send me the page details and I can do this
part for you any time.
